function sortStringAlphabetically(str) {
    return str.split('').sort().join('');
}

let inputString = "webmaster";
console.log(sortStringAlphabetically(inputString));
